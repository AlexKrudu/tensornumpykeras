"""
tensornumpykeras module made for KeKW and LULz
"""

__version__ = "0.0.1"
__author__ = 'Alexandr Krudu'
__credits__ = 'ITMO University'