Kekw + lulz python module
-----